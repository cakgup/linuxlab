# Draft Migrasi Infrastruktur MOFCG ke Azure Cloud (Tahun 2027)
provider "azurerm" {
  features {}
}

resource "azurerm_resource_group" "mofcg_rg" {
  name     = "rg-mofcg-prod-southeastasia"
  location = "Southeast Asia"
}

resource "azurerm_virtual_network" "mofcg_vnet" {
  name                = "vnet-mofcg-core"
  address_space       = ["10.100.0.0/16"]
  location            = azurerm_resource_group.mofcg_rg.location
  resource_group_name = azurerm_resource_group.mofcg_rg.name
}
